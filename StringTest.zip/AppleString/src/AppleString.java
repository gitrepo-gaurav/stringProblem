
class AppleString {
	String str;
	char ch;
	public AppleString(){
		str = "enter";
		ch = 'e';
	}
	public static void main(String[] args){
		AppleString as = new AppleString();
		as.eachCharMethod1(as.getStr(), as.getCh());
		as.allAtOnce(as.getStr(), as.getCh());
	}
	public String eachCharMethod1(String str, char ch){
		String str2="";
		for(int i=0;i<str.length();i++){
			if(str.charAt(i)!=ch){
				str2=str2.concat(Character.toString(str.charAt(i)));
			}
		}
		//System.out.println("eachCharMethod1 Output: "+str2);
		return str2;
	}

	public String allAtOnce(String str, char ch){
		String str3 ="";
		str3 = str.replaceAll("["+ch+"\\s]+","");
		//System.out.println("allAtOnce Output: "+str3);
		return str3;
	}
	public String getStr() {
		return str;
	}
	public void setStr(String str) {
		this.str = str;
	}
	public char getCh() {
		return ch;
	}
	public void setCh(char ch) {
		this.ch = ch;
	}
}
