import org.testng.Assert;
import org.testng.annotations.Test;


public class TestClass {
	AppleString as = new AppleString();
	
	@Test
	public void eachCharMethod1Pass(){
		Assert.assertEquals(as.eachCharMethod1("enter",'e'), "ntr"); // first character
		Assert.assertEquals(as.eachCharMethod1("enter",'n'), "eter"); // any character in the middle
		Assert.assertEquals(as.eachCharMethod1("enter",'r'), "ente"); // last character
		Assert.assertEquals(as.eachCharMethod1("enter",'R'), "enter"); // uppercase character
		Assert.assertEquals(as.eachCharMethod1("enter",'*'), "enter"); // special symbol
		Assert.assertEquals(as.eachCharMethod1("enter",'\\'), "enter"); // special symbol
	}
	
	@Test
	public void allAtOncePass(){
		Assert.assertEquals(as.allAtOnce("enter", 'e'), "ntr"); // first character
		Assert.assertEquals(as.allAtOnce("enter", 't'), "ener");// any character in the middle
		Assert.assertEquals(as.allAtOnce("enter", 'r'), "ente"); // last character
		Assert.assertEquals(as.allAtOnce("enter",'R'), "enter"); // uppercase character
		Assert.assertEquals(as.allAtOnce("enter",'*'), "enter"); // special symbol
		Assert.assertEquals(as.allAtOnce("enter",'\\'), "enter"); // special symbol


	}
	@Test
	public void eachCharMethod1Fail(){
		Assert.assertNotEquals(as.eachCharMethod1("enter",'e'), "enter");
		Assert.assertNotEquals(as.eachCharMethod1("enter",'n'), "enter");
		Assert.assertNotEquals(as.eachCharMethod1("enter",'r'), "enter");
		Assert.assertNotEquals(as.eachCharMethod1("enter",'R'), "ente");
	}
	
	@Test
	public void allAtOnceFail(){
		Assert.assertNotEquals(as.allAtOnce("enter", 'e'), "enter");
		Assert.assertNotEquals(as.allAtOnce("enter", 'n'), "enter");
		Assert.assertNotEquals(as.allAtOnce("enter", 'r'), "enter");
		Assert.assertNotEquals(as.allAtOnce("enter",'R'), "ente");
	}
}
